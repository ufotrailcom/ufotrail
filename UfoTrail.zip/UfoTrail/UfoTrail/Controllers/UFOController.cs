﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UfoTrail.Models;

namespace UfoTrail.Controllers
{
    public class UFOController : Controller
    {
        //
        // GET: /UFO/

        public ActionResult Index(int id)
        {
            UFO ufo;
            try
            {
                using (UfoTrailContext cms = new UfoTrailContext())
                {
                    ufo = cms.UFOs.Find(id);

                    List<Quote> quotes = ufo.ReportQuotes.ToList();
                    ufo.ReportQuotes = quotes;

                    var docQuery = from document in ufo.Documents
                                   select new
                                   {
                                       FileName = document.FileName,
                                       DocumentId = document.DocumentID
                                   };

                    var docs = docQuery.ToList();
                    List<Document> documents = new List<Document>();
                    foreach (var doc in docs)
                    {
                        Document d = new Document();
                        d.FileName = doc.FileName;
                        d.DocumentID = doc.DocumentId;
                        documents.Add(d);
                    }

                    ufo.Documents = documents;

                    var picQuery = from picture in ufo.Pictures
                                   select new
                                   {
                                       FileName = picture.FileName,
                                       PictureID = picture.PictureID
                                   };

                    var pics = picQuery.ToList();
                    List<Picture> pictures = new List<Picture>();
                    foreach (var pic in pics)
                    {
                        Picture p = new Picture();
                        p.FileName = pic.FileName;
                        p.PictureID = pic.PictureID;
                        pictures.Add(p);
                    }

                    ufo.Pictures = pictures;

                    var vidQuery = from video in ufo.Videos
                                   select new
                                   {
                                       FileName = video.FileName,
                                       VideoID = video.VideoID
                                   };

                    var vids = vidQuery.ToList();
                    List<Video> vidoes = new List<Video>();
                    foreach (var vid in vids)
                    {
                        Video v = new Video();
                        v.FileName = vid.FileName;
                        v.VideoID = vid.VideoID;
                        vidoes.Add(v);
                    }

                    ufo.Videos = vidoes;
                }
            }
            catch (Exception e)
            {
                return new HttpNotFoundResult();
            }
            return View(ufo);
        }        

        public ActionResult Create()
        {
            return View();
        }

    }
}
