﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UfoTrail.Models;

namespace UfoTrail.Controllers
{
    public class ImageController : Controller
    {
        //
        // GET: /Image/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Document(int id)
        {
            UfoTrail.Models.Document doc = new Document();

            try
            {
                using (UfoTrailContext cms = new UfoTrailContext())
                {
                    string filename = (from d in cms.Documents where d.DocumentID == id select d.FileName).First();
                    doc.FileName = filename;
                    doc.DocumentID = id;
                }
            }
            catch(Exception e)
            {
                return new HttpNotFoundResult();
            }

            return View(doc);
        }

        public ActionResult Picture(int id)
        {
            UfoTrail.Models.Picture pic = new Picture();

            try
            {
                using (UfoTrailContext cms = new UfoTrailContext())
                {
                    string filename = (from p in cms.Pictures where p.PictureID == id select p.FileName).First();
                    pic.FileName = filename;
                    pic.PictureID = id;
                }
            }
            catch (Exception e)
            {
                return new HttpNotFoundResult();
            }

            return View(pic);
        }

        public FileContentResult getDocumentImg(int id)
        {
            using (UfoTrailContext cms = new UfoTrailContext())
            {
                byte[] byteArray = cms.Documents.Find(id).Data;
                if (byteArray != null)
                {
                    return new FileContentResult(byteArray, "image/jpeg");
                }
                else
                {
                    return null;
                }
            }
        }

        public FileContentResult getPictureImg(int id)
        {
            using (UfoTrailContext cms = new UfoTrailContext())
            {
                byte[] byteArray = cms.Pictures.Find(id).Data;
                if (byteArray != null)
                {
                    return new FileContentResult(byteArray, "image/jpeg");
                }
                else
                {
                    return null;
                }
            }
        }

    }
}
