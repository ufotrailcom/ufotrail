﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using UfoTrail.Models;

namespace UfoTrail.Controllers
{
    public class UFOAPIController : ApiController
    {
        [HttpGet]
        public List<UFO> GetUFOs(double north, double east, double south, double west)
        {
            List<UFO> ufos = new List<UFO>();
            using (UfoTrailContext cms = new UfoTrailContext())
            {
                var query = from ufo in cms.UFOs select ufo;
                ufos = query.ToList();

                foreach (UFO ufo in ufos)
                {

                    List<Quote> quotes = ufo.ReportQuotes.ToList();

                    var docQuery = from document in ufo.Documents
                                   select new
                                   {
                                       FileName = document.FileName,
                                       DocumentId = document.DocumentID
                                   };

                    var docs = docQuery.ToList();
                    List<Document> documents = new List<Document>();
                    foreach (var doc in docs)
                    {
                        Document d = new Document();
                        d.FileName = doc.FileName;
                        d.DocumentID = doc.DocumentId;
                        documents.Add(d);
                    }

                    ufo.Documents = documents;

                    var picQuery = from picture in ufo.Pictures
                                   select new
                                   {
                                       FileName = picture.FileName,
                                       PictureID = picture.PictureID
                                   };

                    var pics = picQuery.ToList();
                    List<Picture> pictures = new List<Picture>();
                    foreach (var pic in pics)
                    {
                        Picture p = new Picture();
                        p.FileName = pic.FileName;
                        p.PictureID = pic.PictureID;
                        pictures.Add(p);
                    }

                    ufo.Pictures = pictures;

                    var vidQuery = from video in ufo.Videos
                                   select new
                                   {
                                       FileName = video.FileName,
                                       VideoID = video.VideoID
                                   };

                    var vids = vidQuery.ToList();
                    List<Video> vidoes = new List<Video>();
                    foreach (var vid in vids)
                    {
                        Video v = new Video();
                        v.FileName = vid.FileName;
                        v.VideoID = vid.VideoID;
                        vidoes.Add(v);
                    }

                    ufo.Videos = vidoes;         
                }
            }
            return ufos;
        }
    }
}
