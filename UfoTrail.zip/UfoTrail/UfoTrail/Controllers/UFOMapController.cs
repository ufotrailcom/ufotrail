﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UfoTrail.Models;

namespace UfoTrail.Controllers
{
    public class UFOMapController : Controller
    {
        //
        // GET: /UFOMap/

        public ActionResult Index()
        {
            
            return View();
        }

    }
}
