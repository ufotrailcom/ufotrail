﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using UfoTrail.Models;

public static class Extensions
{
    /// <summary>
    /// Extension method to return the style attribute required for the navigation based on the current controller
    /// </summary>
    /// <param name="htmlHelper">The HTML Helper</param>
    /// <param name="controllerName">The controller that the navigation element matches</param>
    /// <returns>The class name or an empty string if the controller does not match the current controller</returns>
    public static string ActiveNavStyle(this HtmlHelper htmlHelper, string controllerName, string actionName)
    {
        if (((string)htmlHelper.ViewContext.RouteData.Values["controller"]).Equals(controllerName, StringComparison.OrdinalIgnoreCase)
            &&((string)htmlHelper.ViewContext.RouteData.Values["action"]).Equals(actionName, StringComparison.OrdinalIgnoreCase))
            return "active";
        else
            return String.Empty;
    }

    /// <summary>
    /// This will build a Label as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString LabelWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, object htmlAttributes = null)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description }, { "placeholder", metaData.Watermark } };
        }
        else
        {
            Dictionary<string, object> atts = new Dictionary<string, object>();

            PropertyInfo[] props = htmlAttributes.GetType().GetProperties();
            foreach (PropertyInfo prop in props)
            {
                atts.Add(prop.Name, prop.GetValue(htmlAttributes));
            }

            if (htmlAttributes.GetType().GetProperty("title") == null && !string.IsNullOrEmpty(metaData.Description))
                atts.Add("title", metaData.Description);

            htmlAttributes = atts;

        }

        return helper.LabelFor(expression, (IDictionary<string, object>)htmlAttributes);
    }

    /// <summary>
    /// This will build a Label as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString LabelWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, IDictionary<string, object> htmlAttributes)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description }, { "placeholder", metaData.Watermark } };
        }
        else
        {
            if (!string.IsNullOrEmpty(metaData.Description) && !htmlAttributes.Keys.Contains("title"))
                htmlAttributes.Add("title", metaData.Description);
        }

        return helper.LabelFor(expression, (IDictionary<string, object>)htmlAttributes);
    }

    /// <summary>
    /// This will build a text box as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used. It will also use the 
    /// modal "Prompt" for "placeholder" if available from the modal, and once again, if "placeholder" is passed in
    /// then the modal version is ignored.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString TextBoxWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, object htmlAttributes = null, bool useTextArea = false)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description }, { "placeholder", metaData.Watermark } };
        }
        else
        {
            Dictionary<string, object> atts = new Dictionary<string, object>();

            PropertyInfo[] props = htmlAttributes.GetType().GetProperties();
            foreach (PropertyInfo prop in props)
            {
                atts.Add(prop.Name, prop.GetValue(htmlAttributes));
            }

            if (htmlAttributes.GetType().GetProperty("title") == null && !string.IsNullOrEmpty(metaData.Description))
                atts.Add("title", metaData.Description);

            if (htmlAttributes.GetType().GetProperty("placeholder") == null && !string.IsNullOrEmpty(metaData.Watermark))
                atts.Add("placeholder", metaData.Watermark);

            if (useTextArea)
            {
                if (htmlAttributes.GetType().GetProperty("rows") == null)
                    atts.Add("rows", 4);
            }

            htmlAttributes = atts;
        }

        if (useTextArea)
        {
            return helper.TextAreaFor(expression, (IDictionary<string, object>)htmlAttributes);
        }
        else
        {
            return helper.TextBoxFor(expression, (IDictionary<string, object>)htmlAttributes);
        }
    }

    /// <summary>
    /// This will build a text box as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used. It will also use the 
    /// modal "Prompt" for "placeholder" if available from the modal, and once again, if "placeholder" is passed in
    /// then the modal version is ignored.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString TextBoxWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, IDictionary<string, object> htmlAttributes, bool useTextArea = false)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description } };
        }
        else
        {
            if (!string.IsNullOrEmpty(metaData.Description) && !htmlAttributes.Keys.Contains("title"))
                htmlAttributes.Add("title", metaData.Description);

            if (!string.IsNullOrEmpty(metaData.Watermark) && !htmlAttributes.Keys.Contains("placeholder"))
                htmlAttributes.Add("placeholder", metaData.Watermark);

            if (useTextArea)
            {
                if (htmlAttributes.GetType().GetProperty("rows") == null)
                    htmlAttributes.Add("rows", 4);
            }
        }

        if (useTextArea)
        {
            return helper.TextAreaFor(expression, (IDictionary<string, object>)htmlAttributes);
        }
        else
        {
            return helper.TextBoxFor(expression, (IDictionary<string, object>)htmlAttributes);
        }
    }

    public static string GetString(this DataRow row, string name)
    {
        return (row[name] == null || row[name] == DBNull.Value) ? null : row[name].ToString();
    }

    public static string ToCamelCase(this string value)
    {
        string result = "";

        string[] words = value.Split(" ".ToCharArray());

        foreach (string word in words)
        {
            if (word.Length >1)
            {
                string w = word[0].ToString().ToUpper() + word.Substring(1);
                result += w;
            }
            else if (word.Length == 1)
            {
                result += word.ToUpper();
            }
        }

        return result;
    }

    /// <summary>
    /// This will build a Label as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString DisplayNameWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, object htmlAttributes = null)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description }, { "placeholder", metaData.Watermark } };
        }
        else
        {
            Dictionary<string, object> atts = new Dictionary<string, object>();

            PropertyInfo[] props = htmlAttributes.GetType().GetProperties();
            foreach (PropertyInfo prop in props)
            {
                atts.Add(prop.Name, prop.GetValue(htmlAttributes));
            }

            if (htmlAttributes.GetType().GetProperty("title") == null && !string.IsNullOrEmpty(metaData.Description))
                atts.Add("title", metaData.Description);

            htmlAttributes = atts;

        }
        TagBuilder span = new TagBuilder("span");

        foreach (string key in ((Dictionary<string, object>)htmlAttributes).Keys)
        {
            if (((Dictionary<string, object>)htmlAttributes)[key] != null)
            {
                span.Attributes.Add(key, ((Dictionary<string, object>)htmlAttributes)[key].ToString());
            }
        }
        string name = String.IsNullOrEmpty(metaData.DisplayName) ? metaData.PropertyName : metaData.DisplayName;
        span.SetInnerText(name);

        MvcHtmlString mspan = new MvcHtmlString(span.ToString());


        return mspan;
    }

    /// <summary>
    /// This will build a Label as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString DisplayWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, object htmlAttributes = null)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description }, { "placeholder", metaData.Watermark } };
        }
        else
        {
            Dictionary<string, object> atts = new Dictionary<string, object>();

            PropertyInfo[] props = htmlAttributes.GetType().GetProperties();
            foreach (PropertyInfo prop in props)
            {
                atts.Add(prop.Name, prop.GetValue(htmlAttributes));
            }

            if (htmlAttributes.GetType().GetProperty("title") == null && !string.IsNullOrEmpty(metaData.Description))
                atts.Add("title", metaData.Description);

            htmlAttributes = atts;

        }
        TagBuilder span = new TagBuilder("span");

        foreach (string key in ((Dictionary<string, object>)htmlAttributes).Keys)
        {
            if (((Dictionary<string, object>)htmlAttributes)[key] != null)
            {
                span.Attributes.Add(key, ((Dictionary<string, object>)htmlAttributes)[key].ToString());
            }
        }
        string value = (metaData.Model == null) ? "" : metaData.Model.ToString();
        if (metaData.Model != null && metaData.Model.GetType().IsEnum)
        {
            value = ((Enum)metaData.Model).GetAttributeOfType<DescriptionAttribute>().Description;
        }
        else if (metaData.Model != null && metaData.Model.GetType() == typeof(List<Quote>))
        {
            value = "";
            foreach (Quote quote in (List<Quote>)metaData.Model)
            {
                if (value != "")
                {
                    value += ", ";
                }
                value += quote.TheQuote;
            }
        }
        span.SetInnerText(value);

        MvcHtmlString mspan = new MvcHtmlString(span.ToString());


        return mspan;
    }

    /// <summary>
    /// This will build a Label as normal, but it will also contain tool tips provided from the model. If a "title" is 
    /// passed to the method in the htmlAttributes then the modal "Description" wont be used.
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    /// <typeparam name="TValue"></typeparam>
    /// <param name="helper"></param>
    /// <param name="expression"></param>
    /// <param name="htmlAttributes"></param>
    /// <returns></returns>
    public static MvcHtmlString DisplayTimeSpanWithTooltipFor<TModel, TValue>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TValue>> expression, object htmlAttributes = null)
    {
        var metaData = ModelMetadata.FromLambdaExpression(expression, helper.ViewData);

        if (htmlAttributes == null)
        {
            htmlAttributes = new Dictionary<string, object> { { "title", metaData.Description }, { "placeholder", metaData.Watermark } };
        }
        else
        {
            Dictionary<string, object> atts = new Dictionary<string, object>();

            PropertyInfo[] props = htmlAttributes.GetType().GetProperties();
            foreach (PropertyInfo prop in props)
            {
                atts.Add(prop.Name, prop.GetValue(htmlAttributes));
            }

            if (htmlAttributes.GetType().GetProperty("title") == null && !string.IsNullOrEmpty(metaData.Description))
                atts.Add("title", metaData.Description);

            htmlAttributes = atts;

        }
        TagBuilder span = new TagBuilder("span");

        foreach (string key in ((Dictionary<string, object>)htmlAttributes).Keys)
        {
            if (((Dictionary<string, object>)htmlAttributes)[key] != null)
            {
                span.Attributes.Add(key, ((Dictionary<string, object>)htmlAttributes)[key].ToString());
            }
        }
        string value = "";

        if (metaData.Model != null && metaData.Model.GetType() == typeof(System.Int64))
        {
            TimeSpan ts = new TimeSpan(((long)metaData.Model));
            value = ts.ToString();
        }

        span.SetInnerText(value);

        MvcHtmlString mspan = new MvcHtmlString(span.ToString());


        return mspan;
    }

    /// <summary>
    /// Gets an attribute on an enum field value
    /// </summary>
    /// <typeparam name="T">The type of the attribute you want to retrieve</typeparam>
    /// <param name="enumVal">The enum value</param>
    /// <returns>The attribute of type T that exists on the enum value</returns>
    public static T GetAttributeOfType<T>(this Enum enumVal) where T : System.Attribute
    {
        var type = enumVal.GetType();
        var memInfo = type.GetMember(enumVal.ToString());
        var attributes = memInfo[0].GetCustomAttributes(typeof(T), false);
        return (T)attributes[0];
    }

    
}