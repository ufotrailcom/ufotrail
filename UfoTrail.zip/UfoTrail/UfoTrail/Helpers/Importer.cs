﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Validation;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using UfoTrail.Models;

namespace UfoTrail.Helpers
{
    public class Importer
    {
        public static void ImportOldData(string filename)
        {
            string ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filename + ";Extended Properties=Excel 12.0;";

            using (OleDbConnection conn = new System.Data.OleDb.OleDbConnection(ConnectionString))
            {
                conn.Open();
                using (DataTable dtExcelSchema = conn.GetSchema("Tables"))
                {
                    string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                    string query = "SELECT * FROM [" + sheetName + "]";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "Items");
                    List<UFO> ufos = new List<UFO>();
                    List<Document> documents = new List<Document>();
                    List<Quote> quotes = new List<Quote>();
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                DataRow row = ds.Tables[0].Rows[i];
                                string sUsable = row.GetString("Usable");
                                if (!String.IsNullOrEmpty(sUsable) && Boolean.Parse(sUsable))
                                {
                                    UFO ufo = new UFO();
                                    Document document = new Document();
                                    ufo.Description = row.GetString("Description");

                                    if (!string.IsNullOrEmpty(ufo.Description))
                                    {
                                        foreach (Match match in Regex.Matches(ufo.Description, "\"([^\"]*)\""))
                                        {
                                            ufo.Description = ufo.Description.Replace(match.Value, "");
                                            Quote q = new Quote();
                                            q.TheQuote = match.Value;
                                            ufo.ReportQuotes.Add(q);
                                            quotes.Add(q);
                                        }

                                        if (ufo.Description == "")
                                        {
                                            ufo.Description = "See report quotes.";
                                        }
                                    }

                                    string mType = row["Type"].ToString();
                                    ReportType type;
                                    Enum.TryParse<ReportType>(mType, out type);
                                    ufo.ReportType = type;

                                    string primaryId = row.GetString("PrimaryId");
                                    string subIds = row.GetString("SubId");
                                    subIds = subIds.Replace(".", ",");
                                    string[] subs = subIds.Split(",".ToCharArray());
                                    foreach (string sub in subs)
                                    {
                                        int subId = Int32.Parse(sub);
                                        string s = subId.ToString("0000");
                                        string f = primaryId + "_" + s + ".jpg";
                                        document = new Document();
                                        document.Extenstion = ".jpg";
                                        document.FileName = f;
                                        
                                        //todo load image;
                                        FileStream fs = File.OpenRead("F:\\flying saucer\\" + f);
                                        document.Data = new byte[fs.Length];
                                        fs.Read(document.Data, 0, (int)fs.Length);

                                        documents.Add(document);
                                        ufo.Documents.Add(document);
                                    }

                                    ufo.Location = row.GetString("Location");

                                    string url = "http://maps.googleapis.com/maps/api/geocode/json?sensor=true&address=";

                                    dynamic googleResults = new Uri(url + ufo.Location).GetDynamicJsonObject();
                                    foreach (var result in googleResults.results)
                                    {
                                        //Console.WriteLine("[" + result.geometry.location.lat + "," + result.geometry.location.lng + "] " + result.formatted_address);
                                        ufo.Latitude = result.geometry.location.lat;
                                        ufo.Longitude = result.geometry.location.lng;
                                        break;
                                    }


                                    string sAltitude = row.GetString("Altitude");
                                    if (String.IsNullOrEmpty(sAltitude))
                                    {
                                        ufo.Altitude = null;
                                    }
                                    else
                                    {
                                        double feet = Double.Parse(sAltitude);
                                        double alt = feet * 0.3048;
                                        ufo.Altitude = alt;
                                    }

                                    string dir = row.GetString("Direction");

                                    if (String.IsNullOrEmpty(dir))
                                    {
                                        ufo.Direction = Direction.Unknown;
                                    }
                                    else
                                    {
                                        Direction direction;
                                        if (Enum.TryParse<Direction>(dir.ToCamelCase(), out direction))
                                        {
                                            ufo.Direction = direction;
                                        }
                                        else
                                        {
                                            ufo.Direction = Direction.Unknown;
                                        }
                                    }

                                    ufo.Shape = row.GetString("Shape");
                                    ufo.Colour = row.GetString("Colour");
                                    ufo.Sound = row.GetString("Sound");

                                    string sNumber = row.GetString("Number");
                                    if (!String.IsNullOrEmpty(sNumber))
                                    {
                                        int number;
                                        if (Int32.TryParse(sNumber, out number))
                                        {
                                            ufo.Number = number;
                                            ufo.MultipleObjects = (number > 1);
                                        }
                                        else if (sNumber.ToLower() == "multiple")
                                        {
                                            ufo.MultipleObjects = true;
                                        }
                                    }

                                    string sDate = row["Date and time"] == null ? null : row["Date and time"].ToString();
                                    if (!String.IsNullOrEmpty(sDate))
                                    {
                                        DateTime date;
                                        if (DateTime.TryParse(sDate, out date))
                                        {
                                            ufo.TimeObserved = date;
                                        }
                                    }

                                    string sAliens = row["Aliens"] == null ? null : row["Aliens"].ToString();
                                    if (!String.IsNullOrEmpty(sAliens))
                                    {
                                        bool aliens;
                                        if (Boolean.TryParse(sAliens, out aliens))
                                        {
                                            ufo.AliensSpotted = aliens;
                                        }
                                    }

                                    string sAdbucted = row["Was abducted"] == null ? null : row["Was abducted"].ToString();
                                    if (!String.IsNullOrEmpty(sAdbucted))
                                    {
                                        bool abducted;
                                        if (Boolean.TryParse(sAdbucted, out abducted))
                                        {
                                            ufo.AbductionOccurred = abducted;
                                        }
                                    }

                                    ufo.AlienDescription = row.GetString("Alien description");

                                    string sSpeed = row.GetString("Speed");
                                    ufo.Speed = sSpeed;
                                    if (!String.IsNullOrEmpty(sSpeed))
                                    {
                                        Match match = Regex.Match(sSpeed, "\\d+");
                                        if (match.Success)
                                        {
                                            bool imperial = sSpeed.ToLower().Contains("mph");
                                            double value = Double.Parse(match.Value);
                                            ufo.ExactSpeed = imperial ? value * 1.60934 : value;

                                            if (ufo.ExactSpeed < 20)
                                            {
                                                ufo.RelativeSpeed = Speed.VerySlow;
                                            }
                                            else if (ufo.ExactSpeed < 80)
                                            {
                                                ufo.RelativeSpeed = Speed.Slow;
                                            }
                                            else if (ufo.ExactSpeed < 150)
                                            {
                                                ufo.RelativeSpeed = Speed.Medium;
                                            }
                                            else if (ufo.ExactSpeed < 400)
                                            {
                                                ufo.RelativeSpeed = Speed.Fast;
                                            }
                                            else
                                            {
                                                ufo.RelativeSpeed = Speed.VeryFast;
                                            }
                                        }
                                        else
                                        {
                                            
                                            sSpeed = sSpeed.ToLower();
                                            string firstSpeed = sSpeed;
                                            string secondSpeed = sSpeed;
                                            if (sSpeed.Contains(" - "))
                                            {
                                                string [] bits = Regex.Split(sSpeed, " - ");
                                                firstSpeed = bits[0];
                                                secondSpeed = bits[1];
                                            }

                                            firstSpeed = firstSpeed.ToCamelCase();
                                            Speed speed;
                                            if (Enum.TryParse<Speed>(firstSpeed, out speed))
                                            {
                                                ufo.RelativeSpeed = speed;

                                                if (Enum.TryParse<Speed>(secondSpeed, out speed))
                                                {
                                                    if (((int)ufo.RelativeSpeed) < ((int)speed))
                                                    {
                                                        ufo.SpeedAlteration = SpeedAlteration.Deceleration;

                                                    }
                                                    else
                                                    {
                                                        ufo.SpeedAlteration = SpeedAlteration.Acceleration;
                                                    }
                                                }
                                            }

                                            
                                        }
                                    }

                                    ufo.Observer = row.GetString("Observer Name");

                                    string sWitnesses = row.GetString("No of witnesses");
                                    if (!String.IsNullOrEmpty(sWitnesses))
                                    {
                                        int witnesses;
                                        if (Int32.TryParse(sWitnesses, out witnesses))
                                        {
                                            ufo.Witnesses = witnesses;
                                            ufo.MultipleWitnesses = witnesses > 1;
                                        }
                                        else if (sWitnesses.ToLower().Contains("multiple"))
                                        {
                                            ufo.MultipleWitnesses = true;
                                        }
                                    }

                                    string sMovement = row.GetString("Movement");
                                    MovementType movement;
                                    ufo.Movement = sMovement;
                                    if (Enum.TryParse<MovementType>(sMovement, out movement))
                                    {
                                        ufo.MovementType = movement;
                                    }

                                    string sWeather = row.GetString("Weather");
                                    if (!String.IsNullOrEmpty(sWeather))
                                    {
                                        ufo.WeatherReported = sWeather;
                                        Weather weather;
                                        if (Enum.TryParse<Weather>(sWeather, out weather))
                                        {
                                            ufo.Weather = weather;
                                        }
                                    }

                                    string sRating = row.GetString("Rating");
                                    if (!String.IsNullOrEmpty(sRating))
                                    {
                                        int rating;
                                        if (Int32.TryParse(sRating, out rating))
                                        {
                                            ufo.Rating = rating;
                                        }
                                    }

                                    string sObserver = row.GetString("Observer type");                                    
                                    if (!String.IsNullOrEmpty(sObserver))
                                    {
                                        ObserverType ob;
                                        if (Enum.TryParse<ObserverType>(sObserver, out ob))
                                        {
                                            ufo.ObserverType = ob;
                                        }
                                    }

                                    string sSize = row.GetString("Size");
                                    ufo.Size = sSize;

                                    string sIllumination = row.GetString("Illuminated");
                                    if (!String.IsNullOrEmpty(sIllumination))
                                    {
                                        bool illumination;
                                        if (Boolean.TryParse(sIllumination, out illumination))
                                        {
                                            ufo.Illuminated = illumination;
                                        }
                                    }

                                    string sDuration = row.GetString("Duration");
                                    if (!String.IsNullOrEmpty(sDuration))
                                    {
                                        int duration;
                                        string durationType;
                                        Match match = Regex.Match(sDuration, "\\d+");
                                        if (match.Success)
                                        {
                                            if (Int32.TryParse(match.Value, out duration))
                                            {
                                                if (sDuration.ToLower().Contains("minute"))
                                                {
                                                    ufo.ObservationDuration = new TimeSpan(0, duration, 0).Ticks;
                                                }
                                                else if (sDuration.ToLower().Contains("second"))
                                                {
                                                    ufo.ObservationDuration = new TimeSpan(0, 0, duration).Ticks;
                                                }
                                            }
                                        }
                                    }

                                    ufos.Add(ufo);
                                    
                                }
                                
                            }
                        }
                    }
                    
                    using (UfoTrailContext context = new UfoTrailContext())
                    {
                        
                        foreach(Document doc in documents)
                        {
                            context.Documents.Add(doc);
                            context.Entry(doc).State = EntityState.Added;
                        }
                        foreach (Quote quote in quotes)
                        {
                            context.Quotes.Add(quote);
                            context.Entry(quote).State = EntityState.Added;
                        }
                        foreach (UFO ufo in ufos)
                        {
                            context.UFOs.Add(ufo);
                            context.Entry(ufo).State = EntityState.Added;
                        }
                        try
                        {
                            context.SaveChanges();
                        }
                        catch (DbEntityValidationException e)
                        {
                            string message = e.Message;
                        }
                    }
                }
            }
        }
    }
}