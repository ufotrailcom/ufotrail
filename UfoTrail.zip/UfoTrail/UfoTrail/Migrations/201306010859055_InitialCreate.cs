namespace UfoTrail.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.UFOes",
                c => new
                    {
                        UFOID = c.Int(nullable: false, identity: true),
                        IsApproved = c.Boolean(nullable: false),
                        ReportType = c.Int(nullable: false),
                        ObserverType = c.Int(nullable: false),
                        Description = c.String(maxLength: 4000),
                        Location = c.String(maxLength: 4000),
                        Latitude = c.Double(nullable: false),
                        Longitude = c.Double(nullable: false),
                        Altitude = c.Double(),
                        Speed = c.String(maxLength: 4000),
                        RelativeSpeed = c.Int(nullable: false),
                        ExactSpeed = c.Double(),
                        SpeedAlteration = c.Int(nullable: false),
                        Movement = c.String(maxLength: 4000),
                        MovementType = c.Int(nullable: false),
                        Direction = c.Int(nullable: false),
                        VerticalMovement = c.Int(nullable: false),
                        Solid = c.Boolean(),
                        Illuminated = c.Boolean(),
                        Shape = c.String(maxLength: 4000),
                        Colour = c.String(maxLength: 4000),
                        Sound = c.String(maxLength: 4000),
                        Number = c.Int(),
                        MultipleObjects = c.Boolean(),
                        TimeObserved = c.DateTime(),
                        Rating = c.Int(nullable: false),
                        Witnesses = c.Int(),
                        MultipleWitnesses = c.Boolean(),
                        ObservationDuration = c.Long(),
                        Length = c.Double(),
                        Width = c.Double(),
                        Diameter = c.Double(),
                        Size = c.String(maxLength: 4000),
                        Weather = c.Int(nullable: false),
                        AliensSpotted = c.Boolean(),
                        AlienDescription = c.String(maxLength: 4000),
                        AbductionOccurred = c.Boolean(),
                        Observer = c.String(maxLength: 4000),
                    })
                .PrimaryKey(t => t.UFOID);
            
            CreateTable(
                "dbo.Documents",
                c => new
                    {
                        DocumentID = c.Int(nullable: false, identity: true),
                        FileName = c.String(maxLength: 4000),
                        Extenstion = c.String(maxLength: 4000),
                        Data = c.Binary(maxLength: 4000),
                        UFO_UFOID = c.Int(),
                    })
                .PrimaryKey(t => t.DocumentID)
                .ForeignKey("dbo.UFOes", t => t.UFO_UFOID)
                .Index(t => t.UFO_UFOID);
            
            CreateTable(
                "dbo.Pictures",
                c => new
                    {
                        PictureID = c.Int(nullable: false, identity: true),
                        FileName = c.String(maxLength: 4000),
                        Extenstion = c.String(maxLength: 4000),
                        Data = c.Binary(maxLength: 4000),
                        UFO_UFOID = c.Int(),
                    })
                .PrimaryKey(t => t.PictureID)
                .ForeignKey("dbo.UFOes", t => t.UFO_UFOID)
                .Index(t => t.UFO_UFOID);
            
            CreateTable(
                "dbo.Videos",
                c => new
                    {
                        VideoID = c.Int(nullable: false, identity: true),
                        FileName = c.String(maxLength: 4000),
                        Extenstion = c.String(maxLength: 4000),
                        Data = c.Binary(maxLength: 4000),
                        UFO_UFOID = c.Int(),
                    })
                .PrimaryKey(t => t.VideoID)
                .ForeignKey("dbo.UFOes", t => t.UFO_UFOID)
                .Index(t => t.UFO_UFOID);
            
        }
        
        public override void Down()
        {
            DropIndex("dbo.Videos", new[] { "UFO_UFOID" });
            DropIndex("dbo.Pictures", new[] { "UFO_UFOID" });
            DropIndex("dbo.Documents", new[] { "UFO_UFOID" });
            DropForeignKey("dbo.Videos", "UFO_UFOID", "dbo.UFOes");
            DropForeignKey("dbo.Pictures", "UFO_UFOID", "dbo.UFOes");
            DropForeignKey("dbo.Documents", "UFO_UFOID", "dbo.UFOes");
            DropTable("dbo.Videos");
            DropTable("dbo.Pictures");
            DropTable("dbo.Documents");
            DropTable("dbo.UFOes");
        }
    }
}
