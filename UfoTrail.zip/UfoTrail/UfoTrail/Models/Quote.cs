﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UfoTrail.Models
{
    public class Quote
    {
        public int QuoteID { get; set; }
        public string TheQuote { get; set; }
    }
}