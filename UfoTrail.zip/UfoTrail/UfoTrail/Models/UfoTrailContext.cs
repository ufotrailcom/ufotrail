﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace UfoTrail.Models
{
    public class UfoTrailContext : DbContext
    {
        public DbSet<UFO> UFOs { get; set; }
        public DbSet<Document> Documents { get; set; }
        public DbSet<Picture> Pictures { get; set; }
        public DbSet<Video> Videos { get; set; }
        public DbSet<Quote> Quotes { get; set; }

        /*public UfoTrailContext()
            : base(UfoTrailContext.ConnectionString)
        {
        }*/

        

        public static string ConnectionString
        {
            get
            {                
                
                string result = @"Data Source=" +
                    System.Reflection
                        .Assembly
                        .GetExecutingAssembly()
                        .Location
                        .Substring(0,
                            System
                            .Reflection
                            .Assembly
                            .GetExecutingAssembly()
                            .Location
                            .LastIndexOf("\\") + 1)
                    + @"\\UFOTrail.sdf";
                return result;
            }
        }
    }
}