﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UfoTrail.Models
{
    public class UFO
    {
        public int UFOID {get;set;}
        public bool IsApproved { get; set; }

        [Display(Name="Report documents", Description="Documents associated with the original report.")]
        public virtual ICollection<Document> Documents { get; set; }

        [Display(Name="Pictures", Description="Pictures uploaded with the report.")]
        public virtual ICollection<Picture> Pictures { get; set; }
        public virtual ICollection<Video> Videos { get; set; }
        [Display(Name="Report type", Description="The type of report that was filed.")]
        public ReportType ReportType { get; set; }
        
        [Display(Name="Observer type", Description="The type of observer that the report was filed by.")]
        public ObserverType ObserverType { get; set; }

        [Display(Name="Description", Description="A brief description of the unidentified flying object.", Prompt="Enter a brief description of the UFO.")]
        public string Description { get; set; }

        [Display(Name="Location", Description="The location where the sighting occurred.", Prompt="Enter an address or location where the sighting occurred.")]
        public string Location { get; set; }

        public double Latitude { get; set; }
        public double Longitude { get; set; }

        [Display(Name="Altitude", Description="The altitude of the unidentified flying object in meters.", Prompt="Enter the altitude of the UFO in meters.")]
        public double? Altitude { get; set; }

        [Display(Name="Speed", Description="A simple description of the speed of the unidentified flying object.", Prompt="Enter how fast the UFO was moving.")]
        public string Speed { get; set; }

        [Display(Name="Relative speed", Description="The speed the unidentified flying object was moving.", Prompt="The speed of the UFO, use this if you don't know the exact speed.")]
        public Speed RelativeSpeed { get; set; }

        [Display(Name="Exact speed", Description="The exact speed of the unidentified flying object in km/h", Prompt="Enter the exact speed of the UFO in km/h")]
        public double? ExactSpeed { get; set; }

        [Display(Name="Speed alteration", Description="States if the unidentified flying object was speeding up, slowing down or remaining steady.")]
        public SpeedAlteration SpeedAlteration { get; set; }

        [Display(Name="Movement", Description="Describes how the unidentified flying object was moving.", Prompt="Enter a description about the UFO's movement.")]
        public string Movement { get; set; }

        [Display(Name="Movement type", Description="Describes how the unidentified flying object was moving")]
        public MovementType MovementType { get; set; }

        [Display(Name="Direction", Description="In what direction was the unidentified flying object was moving")]
        public Direction Direction { get; set; }

        [Display(Name="Vertical direction", Description="Describes if the unidentified flying object is moving in a vertical manner")]
        public VerticalMovement VerticalMovement { get; set; }

        [Display(Name="Was the UFO solid?", Description="If true then the unidentified flying object is solid. Some UFOs are reported as balls of light, they are not solid.")]
        public bool? Solid { get; set; }

        [Display(Name="Was the UFO illuminated?", Description="If true then the unidentified flying object is giving of light.")]
        public bool? Illuminated { get; set; }

        [Display(Name="Shape", Description="A description on the shape of the unidentified flying object.", Prompt="Enter a description on the shape of the UFO.")]
        public string Shape { get; set; }
        
        [Display(Name="Colour", Description="The colour of the unidentified flying object. Some UFOs have numerous colours.", Prompt="Enter a description about the colour of the UFO.")]
        public string Colour { get; set; }

        [Display(Name="Sound", Description="A description about the sound the unidentified flying object made.", Prompt="Enter a description about the sound the UFO made.")]
        public string Sound { get; set; }

        [Display(Name="Number of UFOs", Description="The number of UFOs")]
        public int? Number { get; set; }

        [Display(Name="Multiple UFOs", Description="True of more than one UFO was spotted.")]
        public bool? MultipleObjects { get; set; }

        [Display(Name="Time observed", Description="The date and time the unidentified flying object was observed.")]
        public DateTime? TimeObserved { get; set; }

        [Display(Name="Rating", Description="A rating on how likely the reporting is an alien craft (0) or easily explained (5)")]
        public int Rating { get; set; }

        [Display(Name="Number of witnesses", Description="The number of people who saw the unidentified flying object")]
        public int? Witnesses { get; set; }

        [Display(Name="Had multiple witnesses", Description="True if more than one person saw the unidentified flying object.")]
        public bool? MultipleWitnesses { get; set; }

        [Display(Name="Duration of observation", Description="How long was the unidentified flying object observed for.")]
        public long? ObservationDuration { get; set; }

        [Display(Name="Length", Description="The lenght of the unidentified flying object.")]
        public double? Length { get; set; }

        [Display(Name="Width", Description="The width of the unidentified flying object.")]
        public double? Width { get; set; }

        [Display(Name="Diameter", Description="The diameter of the unidentified flying object.")]
        public double? Diameter { get; set; }

        [Display(Name="Size", Description="A description of the size of the unidentified flying object.", Prompt="Enter a rough size or description of the size if you dont know the exact size of the UFO.")]
        public string Size { get; set; }

        [Display(Name="Weather", Description="The weather condition.")]
        public Weather Weather { get; set; }

        [Display(Name="Weather", Description="The weather condition.")]
        public string WeatherReported { get; set; }

        [Display(Name="Quotes", Description="A list of choice quotes from the original report.")]
        public virtual ICollection<Quote> ReportQuotes { get; set; }

        [Display(Name="Aliens spotted?", Description="True if aliens were spotted.")]
        public bool? AliensSpotted { get; set; }

        [Display(Name="Alien description", Description="A description of the aliens.", Prompt="Describe the aliens you saw.")]
        public string AlienDescription { get; set; }

        [Display(Name="Did the aliens abduct someone?", Description="True if the aliens abducted the observer or someone else.")]
        public bool? AbductionOccurred { get; set; }

        [Display(Name="Observer", Description="The initials of the observer", Prompt="Enter your initials")]
        public string Observer { get; set; }

        public UFO()
        {
            Documents = new List<Document>();
            Pictures = new List<Picture>();
            Videos = new List<Video>();
            ReportQuotes = new List<Quote>();
            ReportType = Models.ReportType.Other;
            Weather = Models.Weather.Unknown;
            VerticalMovement = Models.VerticalMovement.Unknown;
            Direction = Models.Direction.Unknown;
            MovementType = Models.MovementType.Unknown;
            SpeedAlteration = Models.SpeedAlteration.Unknown;
            RelativeSpeed = Models.Speed.Unknown;
            ObserverType = Models.ObserverType.Other;
        }
    }

    public enum ReportType
    {
        [Description("Civilian")]
        Civilian,
        [Description("Military")]
        Military,
        [Description("News paper")]
        NewsPaper,
        [Description("Other")]
        Other
    }

    public enum ObserverType
    {
        [Description("Civilian")]
        Civilian,
        [Description("Military")]
        Military,
        [Description("Other")]
        Other
    }

    public enum Speed
    {
        [Description("Very slow")]
        VerySlow = 0,
        [Description("Slow")]
        Slow = 1,
        [Description("Average")]
        Medium = 2,
        [Description("Fast")]
        Fast = 3,
        [Description("Very fast")]
        VeryFast = 4,
        [Description("Unknown")]
        Unknown = 5
    }

    public enum SpeedAlteration
    {
        [Description("Constant")]
        Constant,
        [Description("Desceleration")]
        Deceleration,
        [Description("Acceleration")]
        Acceleration,
        [Description("Unknown")]
        Unknown
    }

    public enum MovementType
    {
        [Description("Steady")]
        Steady,
        [Description("Hovering")]
        Hovering,
        [Description("Wobly")]
        Wobly,
        [Description("Random")]
        Random,
        [Description("Spiral")]
        Spiral,
        [Description("Zig zag")]
        ZigZag,
        [Description("sharp turns")]
        SharpTurns,
        [Description("Unknown")]
        Unknown
    }

    public enum Direction
    {
        [Description("North")]
        North,
        [Description("East")]
        East,
        [Description("South")]
        South,
        [Description("West")]
        West,
        [Description("North east")]
        NorthEast,
        [Description("South east")]
        SouthEast,
        [Description("North west")]
        NorthWest,
        [Description("South west")]
        SouthWest,
        [Description("Unknown")]
        Unknown
    }

    public enum VerticalMovement
    {
        [Description("Level")]
        Level,
        [Description("Ascending")]
        Ascending,
        [Description("Descending")]
        Descending,
        [Description("Unknown")]
        Unknown
    }

    public enum Weather
    {
        [Description("Fine")]
        Fine,
        [Description("Clear")]
        Clear,
        [Description("Clowdy")]
        Cloudy,
        [Description("Partially cloudy")]
        PartiallyCloudy,
        [Description("Heavy cloud cover")]
        HeavyCloudCover,
        [Description("Light rain")]
        LightRain,
        [Description("Rain")]
        Rain,
        [Description("Heavy rain")]
        HeavyRain,
        [Description("Stormy")]
        Stormy,
        [Description("Hailing")]
        Hailing,
        [Description("Misty")]
        Misty,
        [Description("Light fog")]
        LightFog,
        [Description("Fog")]
        Fog,
        [Description("Heavy fog")]
        HeavyFog,
        [Description("Unknown")]
        Unknown
    }
}

