﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UfoTrail.Models
{
    public class Picture
    {
        public int PictureID { get; set; }
        public string FileName { get; set; }
        public string Extenstion { get; set; }
        [MaxLength]
        public byte[] Data { get; set; }
    }
}