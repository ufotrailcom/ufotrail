﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UfoTrail.Models
{
    public class Document
    {
        public int DocumentID { get; set; }
        public string FileName { get; set; }
        public string Extenstion { get; set; }
        [MaxLength]
        public byte[] Data { get; set; }
    }
}