﻿var markers = {};
var infoWindow;

function initialize() {
    var mapOptions = {
        center: new google.maps.LatLng(-34.397, 150.644),
        zoom: 4,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("map_canvas"),
        mapOptions);

    $.getJSON('/api/UFOAPI/GetUFOs', {north:0, east:0, south:0, west:0},
        function (ufos) {            
            for (i in ufos) {
                var ufo = ufos[i];
                var icon = new google.maps.MarkerImage('/Images/ufo_icon' + ufo.Rating + '.gif', new google.maps.Size(76, 44), new google.maps.Point(0, 0), new google.maps.Point(13, 16), new google.maps.Size(27, 16));
                var markerOption = {
                    map: map,
                    position: new google.maps.LatLng(ufo.Latitude, ufo.Longitude),
                    title: "Ufo",
                    code: ufo.UFOID,
                    clickable: true,
                    icon: icon,
                    visible: true,
                    ufo: ufo
                };
                var marker = new google.maps.Marker(markerOption);
                markers[ufo.UFOID] = marker;
                google.maps.event.addListener(marker, 'click', function () {
                    markerClick(this.code);
                });
            }
        }
        ).fail(function (jqxhr, textStatus, error) {
            var err = textStatus + ', ' + error;
            //alert("Request Failed: " + err);
        });
}

function markerClick(id) {
    var template = $("#ufoTemplate").clone().html();
    template = template.replace("{{Description}}", markers[id].ufo.Description)
    .replace("{{ID}}", markers[id].ufo.UFOID);

    if (infoWindow != null) {
        infoWindow.close();
        infoWindow = null;
    }
    
    infoWindow = new google.maps.InfoWindow(
            {
                content: template,
                position: markers[id].getPosition()
            });
    infoWindow.open(markers[id].getMap());
}

google.maps.event.addDomListener(window, 'load', initialize);